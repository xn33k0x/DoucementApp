plugins {
    id("com.android.application")
}

android {
    namespace = "com.doucement.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.doucement.app"
        minSdk = 26
        //noinspection EditedTargetSdkVersion
        targetSdk = 37
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
